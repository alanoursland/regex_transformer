"""Regex Transformer - Phase 1 FSM Learning Framework"""

__version__ = "0.1.0"
