"""Tests for experiment scripts."""
