"""Tests for FSM core."""
